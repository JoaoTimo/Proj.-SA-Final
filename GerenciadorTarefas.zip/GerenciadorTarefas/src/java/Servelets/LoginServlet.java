package Servelets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet("/LoginServlet") // especifica a url que o servlet responde
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection connecta = DriverManager.getConnection("jdbc:mysql://localhost:3306/gerenciamentoTarefas", "root", "");

                // Select do SQL para verificar se o usuário está bloqueado
                String sqlCheckStatus = "SELECT status_ativo, tentativas FROM Users WHERE nome_usu = ?";
                PreparedStatement checkStatusStmt = connecta.prepareStatement(sqlCheckStatus);
                checkStatusStmt.setString(1, username);
                ResultSet rsStatus = checkStatusStmt.executeQuery();

                if (rsStatus.next()) {
                    String status_ativo = rsStatus.getString("status_ativo");
                    int tentativas = rsStatus.getInt("tentativas");

                    if (status_ativo.equals("bloqueado")) {
                        response.setContentType("text/html");
                        PrintWriter out = response.getWriter();
                        out.println("<html><body><h3>Você teve a conta bloqueada</h3></body></html>");
                        return; // Impede qualquer outra saída após esta mensagem
                    } else if(status_ativo.equals("ativo")){
                        response.sendRedirect("inicio.html");
                    }
                    

                    // Verifica as credenciais
                    String sql = "SELECT * FROM Users WHERE nome_usu = ? AND senha_usu = ?";
                    PreparedStatement statement = connecta.prepareStatement(sql);
                    statement.setString(1, username);
                    statement.setString(2, password);
                    ResultSet rs = statement.executeQuery();
                    
                    if (rs.next()) {
                        // Login bem-sucedido
                        HttpSession session = request.getSession();
                        session.setAttribute("username", username);
                        // Resetar tentativas de login
                        String resetTentativasSql = "UPDATE Users SET tentativas = 0 WHERE nome_usu = ?";
                        PreparedStatement resetStmt = connecta.prepareStatement(resetTentativasSql);
                        resetStmt.setString(1, username);
                        resetStmt.executeUpdate();

                        response.sendRedirect("inicio.html");
                    } else {
                        // Login falhou
                        tentativas++;
                        // Atualiza o número de tentativas
                        String updateTentativasSql = "UPDATE Users SET tentativas = ? WHERE nome_usu = ?";
                        PreparedStatement updateStmt = connecta.prepareStatement(updateTentativasSql);
                        updateStmt.setInt(1, tentativas);
                        updateStmt.setString(2, username);
                        updateStmt.executeUpdate();

                        if (tentativas >= 3) {
                            // Bloqueia o usuário se as tentativas excederem 3
                            String blockUserSql = "UPDATE Users SET status_ativo = 'bloqueado' WHERE nome_usu = ?";
                            PreparedStatement blockStmt = connecta.prepareStatement(blockUserSql);
                            blockStmt.setString(1, username);
                            blockStmt.executeUpdate();

                            response.setContentType("text/html");
                            PrintWriter out = response.getWriter();
                            out.println("<html><body><h3>Você teve a conta bloqueada</h3></body></html>");
                        } else {
                            response.setContentType("text/html");
                            PrintWriter out = response.getWriter();
                            out.println("<html><body><h3>Login falhou. Tentativas restantes: " + (3 - tentativas) + "</h3></body></html>");
                        }
                    }
                } else {
                    response.setContentType("text/html");
                    PrintWriter out = response.getWriter();
                    out.println("<html><body><h3>Usuário não encontrado.</h3></body></html>");
                }

            } catch (Exception e) {
                e.printStackTrace();
                response.setContentType("text/html");
                PrintWriter out = response.getWriter();
                out.println("<html><body><h3>Erro ocorreu ao processar a requisição.</h3></body></html>");
            }
    }
}
