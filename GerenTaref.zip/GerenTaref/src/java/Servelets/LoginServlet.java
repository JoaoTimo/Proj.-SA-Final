package Servelets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Define o tipo de conteúdo da resposta
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        // Usando o padrão de gerenciamento de recursos com try-with-resources para o Connection e PreparedStatement
        try (Connection connecta = DriverManager.getConnection("jdbc:mysql://localhost:3306/gerenTaref", "root", "")) {
            // Carrega o driver do MySQL
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Verificar status do usuário e tentativas
            String sqlCheckStatus = "SELECT status_ativo, tentativas FROM Usuarios WHERE nome_usu = ?";
            try (PreparedStatement checkStatusStmt = connecta.prepareStatement(sqlCheckStatus)) {
                checkStatusStmt.setString(1, username);
                ResultSet rsStatus = checkStatusStmt.executeQuery();

                if (rsStatus.next()) {
                    String status_ativo = rsStatus.getString("status_ativo");
                    int tentativas = rsStatus.getInt("tentativas");

                    // Se a conta está bloqueada
                    if (status_ativo.equals("bloqueado")) {
                        out.println("<html><body><h3>Você teve a conta bloqueada</h3></body></html>");
                        return;
                    }

                    // Verifica as credenciais do usuário
                    String sql = "SELECT * FROM Usuarios WHERE nome_usu = ? AND senha_usu = ?";
                    try (PreparedStatement statement = connecta.prepareStatement(sql)) {
                        statement.setString(1, username);
                        statement.setString(2, password);
                        ResultSet rs = statement.executeQuery();

                        if (rs.next()) {
                            // Login bem-sucedido
                            HttpSession session = request.getSession();
                            session.setAttribute("username", username);
                            
                            // Reseta tentativas
                            String resetTentativasSql = "UPDATE Usuarios SET tentativas = 0 WHERE nome_usu = ?";
                            try (PreparedStatement resetStmt = connecta.prepareStatement(resetTentativasSql)) {
                                resetStmt.setString(1, username);
                                resetStmt.executeUpdate();
                            }

                            response.sendRedirect("inicio.html");
                        } else {
                            // Login falhou
                            tentativas++;
                            String updateTentativasSql = "UPDATE Usuarios SET tentativas = ? WHERE nome_usu = ?";
                            try (PreparedStatement updateStmt = connecta.prepareStatement(updateTentativasSql)) {
                                updateStmt.setInt(1, tentativas);
                                updateStmt.setString(2, username);
                                updateStmt.executeUpdate();
                            }

                            // Se exceder as tentativas, bloqueia o usuário
                            if (tentativas >= 3) {
                                String blockUserSql = "UPDATE Usuarios SET status_ativo = 'bloqueado' WHERE nome_usu = ?";
                                try (PreparedStatement blockStmt = connecta.prepareStatement(blockUserSql)) {
                                    blockStmt.setString(1, username);
                                    blockStmt.executeUpdate();
                                }

                                out.println("<html><body><h3>Você teve a conta bloqueada</h3></body></html>");
                            } else {
                                out.println("<html><body><h3>Login falhou. Tentativas restantes: " + (3 - tentativas) + "</h3></body></html>");
                            }
                        }
                    }
                } else {
                    out.println("<html><body><h3>Usuário não encontrado.</h3></body></html>");
                }
            }

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            // Caso ocorra uma exceção, mostra mensagem de erro
            out.println("<html><body><h3>Erro ao processar a requisição. Tente novamente mais tarde.</h3></body></html>");
        } finally {
            out.close();  // Fechar o PrintWriter
        }
    }
}
